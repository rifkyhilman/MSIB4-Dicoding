import 'regenerator-runtime'; 
import '../styles/main.scss';
import '../styles/responsive.scss';
import './view/render.js';
import './view/navbar.js';